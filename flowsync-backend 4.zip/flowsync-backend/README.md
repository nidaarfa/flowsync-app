# FlowSync Backend 🚀

A production-level backend for a smart commute app with real-time transport tracking, prediction logic, and in-memory data storage.

## 🎯 Features

- **Real-time Transport APIs** - Bus and Metro data with dynamic delays
- **Smart Prediction** - Predicts if you can catch your transport
- **Real-time Updates** - Socket.IO integration for live status/location broadcasts
- **User Management** - Create and manage users in memory
- **Routine Tracking** - Save and retrieve daily commute routines
- **GPS Location Tracking** - Real-time location updates via WebSocket
- **Weather & Routes** - Integration-ready external APIs
- **Analytics** - Commute insights and statistics
- **Production-Ready** - Proper error handling, async/await, and logging

## 🛠 Tech Stack

- **Node.js** - JavaScript runtime
- **Express** - Web framework
- **Socket.IO** - Real-time communication
- **Axios** - HTTP client for external APIs
- **Dotenv** - Environment variables management

## 📦 Installation

```bash
cd flowsync-backend
npm install
```

## 🚀 Getting Started

### Start the Server

```bash
npm start
```

The server will run on `http://localhost:3000` with WebSocket support on `ws://localhost:3000`.

### Development Mode (with auto-reload)

```bash
npm run dev
```

(Requires `nodemon` - included in devDependencies)

## 📡 API Endpoints

### 1. **Basic API**

#### GET `/`
Returns server status.

```bash
curl http://localhost:3000/
```

Response:
```json
{
  "message": "FlowSync Backend Running 🚀"
}
```

---

### 2. **Bus API**

#### GET `/bus`
Returns 3 upcoming buses with delays and status.

```bash
curl http://localhost:3000/bus
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "busNo": "B101",
      "time": "11:50",
      "delay": 5,
      "status": "Slightly Delayed"
    },
    ...
  ],
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 3. **Metro API**

#### GET `/metro`
Returns 3 metro options with routes and delays.

```bash
curl http://localhost:3000/metro
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "line": "Red Line",
      "from": "Station A",
      "to": "Station D",
      "time": "11:49",
      "delay": 2,
      "status": "On Time"
    },
    ...
  ],
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 4. **Combined Transport API**

#### GET `/transport`
Returns both bus and metro data together.

```bash
curl http://localhost:3000/transport
```

Response:
```json
{
  "success": true,
  "data": {
    "bus": [...],
    "metro": [...]
  },
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 5. **Prediction API**

#### GET `/predict?travelTime=30`
Predicts if you can catch bus/metro based on travel time.

```bash
curl "http://localhost:3000/predict?travelTime=30"
```

**Logic**: `currentTime + travelTime <= transportTime`

Response:
```json
{
  "success": true,
  "data": {
    "busResult": "Catch",
    "metroResult": "Catch",
    "bestOption": "Metro",
    "chance": "85%",
    "travelTime": 30,
    "currentTime": "11:46"
  },
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 6. **User API** (In-Memory)

#### POST `/user`
Create a new user.

```bash
curl -X POST http://localhost:3000/user \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "9876543210"
  }'
```

Response:
```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "9876543210",
    "createdAt": "2026-04-24T06:17:35.653Z"
  }
}
```

#### GET `/user`
Retrieve all users.

```bash
curl http://localhost:3000/user
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "9876543210",
      "createdAt": "2026-04-24T06:17:35.653Z"
    }
  ],
  "count": 1,
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 7. **Routine API** (In-Memory)

#### POST `/routine`
Save a commute routine with steps.

```bash
curl -X POST http://localhost:3000/routine \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "name": "Morning Commute",
    "steps": ["Wake up", "Get ready", "Leave house", "Reach station"]
  }'
```

Response:
```json
{
  "success": true,
  "message": "Routine created successfully",
  "data": {
    "id": 1,
    "userId": 1,
    "name": "Morning Commute",
    "steps": ["Wake up", "Get ready", "Leave house", "Reach station"],
    "createdAt": "2026-04-24T06:18:40.509Z"
  }
}
```

#### GET `/routine?userId=1`
Retrieve routines (optionally filtered by userId).

```bash
curl http://localhost:3000/routine?userId=1
```

---

### 8. **Status API** (Real-Time with Socket.IO)

#### POST `/status`
Post a status update and broadcast via Socket.IO.

```bash
curl -X POST http://localhost:3000/status \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "message": "On my way to station",
    "type": "info"
  }'
```

Response:
```json
{
  "success": true,
  "message": "Status posted successfully",
  "data": {
    "id": 1,
    "userId": 1,
    "message": "On my way to station",
    "type": "info",
    "createdAt": "2026-04-24T06:18:44.870Z"
  }
}
```

#### GET `/status`
Retrieve all status updates.

```bash
curl http://localhost:3000/status
```

---

### 9. **Location API** (Real-Time GPS)

#### POST `/location`
Update user location and broadcast via Socket.IO.

```bash
curl -X POST http://localhost:3000/location \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 1,
    "lat": 40.7128,
    "lng": -74.0060
  }'
```

Response:
```json
{
  "success": true,
  "message": "Location updated successfully",
  "data": {
    "id": 1,
    "userId": 1,
    "lat": 40.7128,
    "lng": -74.006,
    "timestamp": "2026-04-24T06:18:52.122Z"
  }
}
```

#### GET `/location?userId=1`
Retrieve locations (optionally filtered by userId).

```bash
curl http://localhost:3000/location?userId=1
```

---

### 10. **Insights API** (Analytics)

#### GET `/insights`
Get commute analytics and statistics.

```bash
curl http://localhost:3000/insights
```

Response:
```json
{
  "success": true,
  "data": {
    "avgCommuteTime": "42 minutes",
    "lateDays": 12,
    "onTimeDays": 38,
    "streak": 5,
    "mostUsedTransport": "Metro",
    "favoriteRoute": "Station A → Station D",
    "weeklyAverage": 38,
    "monthlyAverage": 41,
    "trends": {
      "monday": "Heavy traffic",
      "friday": "Moderate traffic"
    }
  },
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 11. **Route API** (External Integration)

#### GET `/route?source=CityA&destination=CityB`
Get distance and duration between two locations.

```bash
curl "http://localhost:3000/route?source=CityA&destination=CityB"
```

Response:
```json
{
  "success": true,
  "data": {
    "source": "CityA",
    "destination": "CityB",
    "distance": "36 km",
    "duration": "82 minutes",
    "route": "Via Main Street"
  },
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

### 12. **Weather API** (External Integration)

#### GET `/weather?city=NewYork`
Get current weather for a city.

```bash
curl "http://localhost:3000/weather?city=NewYork"
```

Response:
```json
{
  "success": true,
  "data": {
    "city": "NewYork",
    "temperature": "23°C",
    "condition": "Rainy",
    "humidity": "57%",
    "windSpeed": "5 km/h"
  },
  "timestamp": "2026-04-24T06:15:25.664Z"
}
```

---

## 🔌 Socket.IO Real-Time Features

### Connection

```javascript
const socket = io('http://localhost:3000');

socket.on('connect', () => {
  console.log('Connected to server');
});
```

### Listen for Status Updates

```javascript
socket.on('statusUpdate', (data) => {
  console.log('Status update:', data);
});
```

### Listen for Location Updates

```javascript
socket.on('locationUpdate', (data) => {
  console.log('Location update:', data);
});
```

### Emit Status Update

```javascript
socket.emit('statusUpdate', {
  userId: 1,
  message: 'Reached station',
  type: 'success'
});
```

### Emit Location Update

```javascript
socket.emit('locationUpdate', {
  userId: 1,
  lat: 40.7128,
  lng: -74.0060
});
```

---

## 📋 In-Memory Data Storage

All data is stored in memory (arrays/objects):

- **Users** - Array of user objects
- **Routines** - Array of routine objects
- **Statuses** - Array of status updates
- **Locations** - Array of location coordinates

**Note**: Data is cleared when the server restarts. For persistence, implement a database (MongoDB, PostgreSQL, etc.).

---

## 🔐 Environment Variables

Create a `.env` file:

```env
PORT=3000
NODE_ENV=development

# Optional: For real external APIs
# OPENWEATHER_API_KEY=your_openweather_api_key
# OPENROUTE_API_KEY=your_openroute_api_key
```

---

## ⚠️ Error Handling

All endpoints include comprehensive error handling:

```json
{
  "success": false,
  "message": "Error message",
  "error": "Detailed error (development mode only)"
}
```

---

## 🎯 Usage Examples

### Example 1: Create User and Post Status

```bash
# Create user
curl -X POST http://localhost:3000/user \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com"}'

# Post status
curl -X POST http://localhost:3000/status \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"message":"Boarding bus B101","type":"success"}'
```

### Example 2: Check Prediction Before Commute

```bash
# Get available transport
curl http://localhost:3000/transport

# Check prediction with travel time
curl "http://localhost:3000/predict?travelTime=25"
```

### Example 3: Real-time Location Tracking

```bash
# Update location
curl -X POST http://localhost:3000/location \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"lat":40.7128,"lng":-74.0060}'

# Retrieve location
curl "http://localhost:3000/location?userId=1"
```

---

## 📊 Future Enhancements

1. **Database Integration** - Add MongoDB/PostgreSQL for data persistence
2. **Authentication** - JWT tokens for user authentication
3. **Rate Limiting** - Prevent API abuse
4. **Caching** - Redis for frequently accessed data
5. **API Documentation** - Swagger/OpenAPI integration
6. **Testing** - Unit and integration tests
7. **Logging** - Winston or Morgan for detailed logging
8. **Deployment** - Docker containerization and CI/CD

---

## 🤝 Contributing

Feel free to extend and customize the backend for your needs!

---

## 📝 License

ISC

---

**Built with ❤️ for smart commuting**
