const mongoose = require('mongoose');

const LiveStatusSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String },
  location: {
    lat: Number,
    lng: Number,
    updatedAt: { type: Date, default: Date.now }
  },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('LiveStatus', LiveStatusSchema);
