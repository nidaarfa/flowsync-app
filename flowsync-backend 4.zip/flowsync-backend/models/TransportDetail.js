const mongoose = require('mongoose');

const TransportDetailSchema = new mongoose.Schema({
  type: { type: String, enum: ['bus', 'metro', 'other'], required: true },
  name: { type: String, required: true },
  details: { type: Object },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('TransportDetail', TransportDetailSchema);
