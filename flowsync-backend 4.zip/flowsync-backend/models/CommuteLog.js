const mongoose = require('mongoose');

const CommuteLogSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  routine: { type: mongoose.Schema.Types.ObjectId, ref: 'Routine' },
  startTime: { type: Date },
  endTime: { type: Date },
  mode: { type: String },
  details: { type: Object },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('CommuteLog', CommuteLogSchema);
