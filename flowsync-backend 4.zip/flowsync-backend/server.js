require("dotenv").config();

const mongoose = require("mongoose");
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const axios = require("axios");

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
  console.warn("⚠️  MONGO_URI not set in environment. MongoDB will not be used.");
}
let mongoConnected = false;
if (MONGO_URI) {
  mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
      mongoConnected = true;
      console.log("MongoDB Connected ✅");
    })
    .catch((err) => {
      mongoConnected = false;
      console.error("❌ MongoDB connection error:", err.message);
    });
}

// Mongoose Models
const User = require("./models/User");
const Routine = require("./models/Routine");
const Friend = require("./models/Friend");
const LiveStatus = require("./models/LiveStatus");
const CommuteLog = require("./models/CommuteLog");
const TransportDetail = require("./models/TransportDetail");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

// Middleware
app.use(express.json());
app.use(express.static("public")); // Serve static files from public directory

// In-memory data stores
const users = [];
const routines = [];
const statuses = [];
const locations = [];

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Generate random delay between 0-15 minutes
 */
function getRandomDelay() {
  return Math.floor(Math.random() * 15);
}

/**
 * Get current time in HH:MM format
 */
function getCurrentTime() {
  const now = new Date();
  return now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

/**
 * Add minutes to a time string
 */
function addMinutesToTime(timeStr, minutes) {
  const [hours, mins] = timeStr.split(":").map(Number);
  let totalMins = hours * 60 + mins + minutes;
  const newHours = Math.floor(totalMins / 60) % 24;
  const newMins = totalMins % 60;
  return `${String(newHours).padStart(2, "0")}:${String(newMins).padStart(2, "0")}`;
}

/**
 * Convert time string to minutes
 */
function timeToMinutes(timeStr) {
  const [hours, mins] = timeStr.split(":").map(Number);
  return hours * 60 + mins;
}

/**
 * Determine transport status
 */
function getTransportStatus(delay) {
  if (delay === 0) return "On Time";
  if (delay <= 5) return "Slightly Delayed";
  return "Delayed";
}

// ============================================
// 1. BASIC API
// ============================================

app.get("/", (req, res) => {
  res.json({ message: "FlowSync Backend Running 🚀" });
});

// ============================================
// 2. BUS API
// ============================================

app.get("/bus", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const busesDb = await TransportDetail.find({ type: "bus" });
        if (busesDb.length > 0) {
          return res.json({ success: true, data: busesDb, timestamp: new Date().toISOString() });
        }
      } catch (err) {
        return res.status(500).json({ success: false, message: "Error fetching bus data from DB", error: err.message });
      }
    }
    // Fallback mock data
    const currentTime = getCurrentTime();
    const buses = [
      {
        busNo: "B101",
        time: addMinutesToTime(currentTime, 5),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        busNo: "B202",
        time: addMinutesToTime(currentTime, 12),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        busNo: "B303",
        time: addMinutesToTime(currentTime, 20),
        delay: getRandomDelay(),
        status: "On Time",
      },
    ];
    buses.forEach((bus) => {
      bus.status = getTransportStatus(bus.delay);
    });
    res.json({ success: true, data: buses, timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching bus data", error: error.message });
  }
});

// ============================================
// 3. METRO API
// ============================================

app.get("/metro", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const metrosDb = await TransportDetail.find({ type: "metro" });
        if (metrosDb.length > 0) {
          return res.json({ success: true, data: metrosDb, timestamp: new Date().toISOString() });
        }
      } catch (err) {
        return res.status(500).json({ success: false, message: "Error fetching metro data from DB", error: err.message });
      }
    }
    // Fallback mock data
    const currentTime = getCurrentTime();
    const metros = [
      {
        line: "Red Line",
        from: "Station A",
        to: "Station D",
        time: addMinutesToTime(currentTime, 3),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        line: "Blue Line",
        from: "Station B",
        to: "Station E",
        time: addMinutesToTime(currentTime, 8),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        line: "Green Line",
        from: "Station C",
        to: "Station F",
        time: addMinutesToTime(currentTime, 15),
        delay: getRandomDelay(),
        status: "On Time",
      },
    ];
    metros.forEach((metro) => {
      metro.status = getTransportStatus(metro.delay);
    });
    res.json({ success: true, data: metros, timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching metro data", error: error.message });
  }
});

// ============================================
// 4. COMBINED TRANSPORT API
// ============================================

app.get("/transport", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const busesDb = await TransportDetail.find({ type: "bus" });
        const metrosDb = await TransportDetail.find({ type: "metro" });
        if (busesDb.length > 0 || metrosDb.length > 0) {
          return res.json({
            success: true,
            data: { bus: busesDb, metro: metrosDb },
            timestamp: new Date().toISOString(),
          });
        }
      } catch (err) {
        return res.status(500).json({ success: false, message: "Error fetching transport data from DB", error: err.message });
      }
    }
    // Fallback mock data
    const currentTime = getCurrentTime();
    const buses = [
      {
        busNo: "B101",
        time: addMinutesToTime(currentTime, 5),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        busNo: "B202",
        time: addMinutesToTime(currentTime, 12),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        busNo: "B303",
        time: addMinutesToTime(currentTime, 20),
        delay: getRandomDelay(),
        status: "On Time",
      },
    ];
    buses.forEach((bus) => {
      bus.status = getTransportStatus(bus.delay);
    });
    const metros = [
      {
        line: "Red Line",
        from: "Station A",
        to: "Station D",
        time: addMinutesToTime(currentTime, 3),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        line: "Blue Line",
        from: "Station B",
        to: "Station E",
        time: addMinutesToTime(currentTime, 8),
        delay: getRandomDelay(),
        status: "On Time",
      },
      {
        line: "Green Line",
        from: "Station C",
        to: "Station F",
        time: addMinutesToTime(currentTime, 15),
        delay: getRandomDelay(),
        status: "On Time",
      },
    ];
    metros.forEach((metro) => {
      metro.status = getTransportStatus(metro.delay);
    });
    res.json({ success: true, data: { bus: buses, metro: metros }, timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching combined transport data", error: error.message });
  }
});

// ============================================
// 5. PREDICTION API
// ============================================

app.get("/predict", (req, res) => {
  try {
    const currentTime = getCurrentTime();
    const currentMinutes = timeToMinutes(currentTime);
    const travelTime = parseInt(req.query.travelTime) || 30; // Default 30 minutes

    // Generate buses and metros
    const buses = [
      {
        busNo: "B101",
        time: addMinutesToTime(currentTime, 5),
        delay: getRandomDelay(),
      },
      {
        busNo: "B202",
        time: addMinutesToTime(currentTime, 12),
        delay: getRandomDelay(),
      },
      {
        busNo: "B303",
        time: addMinutesToTime(currentTime, 20),
        delay: getRandomDelay(),
      },
    ];

    const metros = [
      {
        line: "Red Line",
        time: addMinutesToTime(currentTime, 3),
        delay: getRandomDelay(),
      },
      {
        line: "Blue Line",
        time: addMinutesToTime(currentTime, 8),
        delay: getRandomDelay(),
      },
      {
        line: "Green Line",
        time: addMinutesToTime(currentTime, 15),
        delay: getRandomDelay(),
      },
    ];

    // Prediction logic: currentTime + travelTime <= transportTime
    const predictBus = (buses) => {
      for (const bus of buses) {
        const busMinutes = timeToMinutes(bus.time) + bus.delay;
        const arrivalTime = currentMinutes + travelTime;
        if (arrivalTime <= busMinutes) {
          return "Catch";
        }
      }
      return "Miss";
    };

    const predictMetro = (metros) => {
      for (const metro of metros) {
        const metroMinutes = timeToMinutes(metro.time) + metro.delay;
        const arrivalTime = currentMinutes + travelTime;
        if (arrivalTime <= metroMinutes) {
          return "Catch";
        }
      }
      return "Miss";
    };

    const busResult = predictBus(buses);
    const metroResult = predictMetro(metros);

    let bestOption = "Bus";
    let chance = "65%";

    if (busResult === "Catch" && metroResult === "Catch") {
      bestOption = "Metro"; // Metro is faster
      chance = "85%";
    } else if (busResult === "Catch") {
      bestOption = "Bus";
      chance = "75%";
    } else if (metroResult === "Catch") {
      bestOption = "Metro";
      chance = "80%";
    } else {
      bestOption = "None";
      chance = "0%";
    }

    res.json({
      success: true,
      data: {
        busResult,
        metroResult,
        bestOption,
        chance,
        travelTime,
        currentTime,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error predicting transport",
      error: error.message,
    });
  }
});

// ============================================
// 6. USER API (IN-MEMORY)
// ============================================

app.post("/user", async (req, res) => {
  console.log("[DEBUG] POST /user hit", req.body);
  try {
    const { name, email, phone } = req.body;
    if (!name) {
      console.warn("[VALIDATION] /user missing name");
      return res.status(400).json({ success: false, error: "Invalid input" });
    }
    if (mongoConnected) {
      try {
        const user = await User.create({ username: name, email, password: "", friends: [] });
        console.log("[DEBUG] /user created in DB", user);
        return res.status(201).json({ success: true, data: user });
      } catch (err) {
        console.error("[ERROR] /user DB error", err.message);
        return res.status(500).json({ success: false, error: "DB error" });
      }
    } else {
      const user = {
        id: users.length + 1,
        name,
        email,
        phone,
        createdAt: new Date().toISOString(),
      };
      users.push(user);
      console.log("[DEBUG] /user created in memory", user);
      return res.status(201).json({ success: true, data: user });
    }
  } catch (error) {
    console.error("[ERROR] /user", error.message);
    return res.status(500).json({ success: false, error: "Server error" });
  }
});

app.get("/user", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const usersDb = await User.find();
        res.json({ success: true, data: usersDb, count: usersDb.length, timestamp: new Date().toISOString() });
      } catch (err) {
        res.status(500).json({ success: false, message: "Error fetching users from DB", error: err.message });
      }
    } else {
      res.json({ success: true, data: users, count: users.length, timestamp: new Date().toISOString() });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching users", error: error.message });
  }
});

// ============================================
// 7. ROUTINE API (IN-MEMORY)
// ============================================

app.post("/routine", async (req, res) => {
  console.log("[DEBUG] POST /routine hit", req.body);
  try {
    const { userId, name, steps } = req.body;
    if (!steps) {
      console.warn("[VALIDATION] /routine missing steps");
      return res.status(400).json({ success: false, error: "Invalid input" });
    }
    if (mongoConnected) {
      try {
        const routine = await Routine.create({ user: userId, name, schedule: steps });
        console.log("[DEBUG] /routine created in DB", routine);
        return res.status(201).json({ success: true, data: routine });
      } catch (err) {
        console.error("[ERROR] /routine DB error", err.message);
        return res.status(500).json({ success: false, error: "DB error" });
      }
    } else {
      const routine = {
        id: routines.length + 1,
        userId,
        name,
        steps,
        createdAt: new Date().toISOString(),
      };
      routines.push(routine);
      console.log("[DEBUG] /routine created in memory", routine);
      return res.status(201).json({ success: true, data: routine });
    }
  } catch (error) {
    console.error("[ERROR] /routine", error.message);
    return res.status(500).json({ success: false, error: "Server error" });
  }
});

app.get("/routine", async (req, res) => {
  try {
    const userId = req.query.userId;
    if (mongoConnected) {
      try {
        const query = userId ? { user: userId } : {};
        const routinesDb = await Routine.find(query);
        res.json({ success: true, data: routinesDb, count: routinesDb.length, timestamp: new Date().toISOString() });
      } catch (err) {
        res.status(500).json({ success: false, message: "Error fetching routines from DB", error: err.message });
      }
    } else {
      const filteredRoutines = userId ? routines.filter((r) => r.userId === parseInt(userId)) : routines;
      res.json({ success: true, data: filteredRoutines, count: filteredRoutines.length, timestamp: new Date().toISOString() });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching routines", error: error.message });
  }
});

// ============================================
// 8. STATUS API (REAL-TIME)
// ============================================

app.post("/status", async (req, res) => {
  console.log("[DEBUG] POST /status hit", req.body);
  try {
    const { name, status: statusMsg } = req.body;
    if (!name || !statusMsg) {
      console.warn("[VALIDATION] /status missing name or status");
      return res.status(400).json({ success: false, error: "Invalid input" });
    }
    let status;
    if (mongoConnected) {
      try {
        status = await LiveStatus.create({ user: name, status: statusMsg });
      } catch (err) {
        console.error("[ERROR] /status DB error", err.message);
        return res.status(500).json({ success: false, error: "DB error" });
      }
    } else {
      status = {
        id: statuses.length + 1,
        userId: name,
        message: statusMsg,
        type: "info",
        createdAt: new Date().toISOString(),
      };
      statuses.push(status);
    }
    // Emit via Socket.IO - BROADCAST to all connected clients
    console.log("[SOCKET] Emitting statusUpdate", status);
    io.emit("statusUpdate", status);
    return res.status(201).json({ success: true, data: status });
  } catch (error) {
    console.error("[ERROR] /status", error.message);
    return res.status(500).json({ success: false, error: "Server error" });
  }
});

app.get("/status", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const statusesDb = await LiveStatus.find();
        res.json({ success: true, data: statusesDb, count: statusesDb.length, timestamp: new Date().toISOString() });
      } catch (err) {
        res.status(500).json({ success: false, message: "Error fetching statuses from DB", error: err.message });
      }
    } else {
      res.json({ success: true, data: statuses, count: statuses.length, timestamp: new Date().toISOString() });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching statuses", error: error.message });
  }
});

// ============================================
// 9. LOCATION API (REAL-TIME GPS)
// ============================================

app.post("/location", async (req, res) => {
  console.log("[DEBUG] POST /location hit", req.body);
  try {
    const { name, lat, lng } = req.body;
    if (!name || lat === undefined || lng === undefined) {
      console.warn("[VALIDATION] /location missing name, lat, or lng");
      return res.status(400).json({ success: false, error: "Invalid input" });
    }
    if (typeof lat !== "number" || typeof lng !== "number") {
      console.warn("[VALIDATION] /location lat/lng not numbers");
      return res.status(400).json({ success: false, error: "Invalid input" });
    }
    let location;
    if (mongoConnected) {
      try {
        location = await LiveStatus.findOneAndUpdate(
          { user: name },
          { $set: { location: { lat, lng, updatedAt: new Date() }, updatedAt: new Date() } },
          { new: true, upsert: true }
        );
      } catch (err) {
        console.error("[ERROR] /location DB error", err.message);
        return res.status(500).json({ success: false, error: "DB error" });
      }
    } else {
      location = {
        id: locations.length + 1,
        userId: name,
        lat,
        lng,
        timestamp: new Date().toISOString(),
      };
      const userLocIndex = locations.findIndex((l) => l.userId === name);
      if (userLocIndex !== -1) {
        locations[userLocIndex] = location;
      } else {
        locations.push(location);
      }
    }
    // Emit via Socket.IO - BROADCAST to all connected clients
    console.log("[SOCKET] Emitting locationUpdate", location);
    io.emit("locationUpdate", location);
    return res.status(201).json({ success: true, data: location });
  } catch (error) {
    console.error("[ERROR] /location", error.message);
    return res.status(500).json({ success: false, error: "Server error" });
  }
});
// ============================================
// TEST SOCKET.IO ROUTE
// ============================================

app.get("/test-socket", (req, res) => {
  const sampleStatus = { userId: "testUser", message: "Test status", type: "info", createdAt: new Date().toISOString() };
  const sampleLocation = { userId: "testUser", lat: 12.34, lng: 56.78, timestamp: new Date().toISOString() };
  console.log("[SOCKET] Emitting test statusUpdate", sampleStatus);
  io.emit("statusUpdate", sampleStatus);
  console.log("[SOCKET] Emitting test locationUpdate", sampleLocation);
  io.emit("locationUpdate", sampleLocation);
  res.json({ success: true, message: "Test events emitted" });
});

app.get("/location", async (req, res) => {
  try {
    const userId = req.query.userId;
    if (mongoConnected) {
      try {
        const query = userId ? { user: userId } : {};
        const locationsDb = await LiveStatus.find(query);
        res.json({ success: true, data: locationsDb, count: locationsDb.length, timestamp: new Date().toISOString() });
      } catch (err) {
        res.status(500).json({ success: false, message: "Error fetching locations from DB", error: err.message });
      }
    } else {
      const filteredLocations = userId ? locations.filter((l) => l.userId === parseInt(userId)) : locations;
      res.json({ success: true, data: filteredLocations, count: filteredLocations.length, timestamp: new Date().toISOString() });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching locations", error: error.message });
  }
});

// ============================================
// 10. INSIGHTS API
// ============================================

app.get("/insights", async (req, res) => {
  try {
    if (mongoConnected) {
      try {
        const logs = await CommuteLog.find();
        if (logs.length > 0) {
          // Example: Calculate average commute time from logs
          const avgCommuteTime = logs.reduce((acc, log) => acc + ((log.endTime && log.startTime) ? ((log.endTime - log.startTime) / 60000) : 0), 0) / logs.length;
          return res.json({
            success: true,
            data: {
              avgCommuteTime: avgCommuteTime ? `${Math.round(avgCommuteTime)} minutes` : "N/A",
              logCount: logs.length,
              // Add more insights as needed
            },
            timestamp: new Date().toISOString(),
          });
        }
      } catch (err) {
        return res.status(500).json({ success: false, message: "Error fetching insights from DB", error: err.message });
      }
    }
    // Fallback dummy insights
    const insights = {
      avgCommuteTime: "42 minutes",
      lateDays: 12,
      onTimeDays: 38,
      streak: 5,
      mostUsedTransport: "Metro",
      favoriteRoute: "Station A → Station D",
      weeklyAverage: 38,
      monthlyAverage: 41,
      trends: {
        monday: "Heavy traffic",
        friday: "Moderate traffic",
      },
    };
    res.json({ success: true, data: insights, timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching insights", error: error.message });
  }
});

// ============================================
// 11. EXTERNAL APIs - ROUTE API
// ============================================

app.get("/route", async (req, res) => {
  console.log("[DEBUG] /route API hit", req.query);
  try {
    const { source, destination } = req.query;
    if (!source || !destination) {
      return res.status(400).json({ success: false, message: "source and destination are required" });
    }
    // Example mapping for coordinates (should be replaced with real mapping)
    const cityCoords = {
      "A": [77.5946, 12.9716], // Bangalore
      "B": [72.8777, 19.0760], // Mumbai
      "C": [88.3639, 22.5726], // Kolkata
      "D": [77.2090, 28.6139], // Delhi
      "E": [80.2707, 13.0827], // Chennai
      "F": [78.4867, 17.3850], // Hyderabad
    };
    const src = cityCoords[source] || [77.5946, 12.9716];
    const dst = cityCoords[destination] || [77.2090, 28.6139];
    let usedFallback = false;
    let apiResponse = null;
    try {
      const apiKey = process.env.OPENROUTE_API_KEY;
      if (!apiKey) throw new Error("OPENROUTE_API_KEY not set");
      const url = `https://api.openrouteservice.org/v2/directions/driving-car?api_key=${apiKey}&start=${src[0]},${src[1]}&end=${dst[0]},${dst[1]}`;
      const response = await axios.get(url);
      apiResponse = response.data;
      console.log("[DEBUG] /route API response:", JSON.stringify(apiResponse));
      const summary = apiResponse.features[0].properties.summary;
      const distance = (summary.distance / 1000).toFixed(2); // km
      const duration = Math.round(summary.duration / 60); // min
      return res.json({
        success: true,
        data: {
          source,
          destination,
          distance: `${distance} km`,
          duration: `${duration} minutes`,
          route: "OpenRouteService",
        },
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      usedFallback = true;
      console.error("[ERROR] /route API error:", err.message);
    }
    // Fallback mock data
    const mockDistance = Math.floor(Math.random() * 50) + 5; // 5-55 km
    const mockDuration = Math.floor(mockDistance * 2) + 10; // rough estimate
    res.json({
      success: true,
      data: {
        source,
        destination,
        distance: `${mockDistance} km`,
        duration: `${mockDuration} minutes`,
        route: usedFallback ? "fallback" : "mock",
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[ERROR] /route API outer error:", error.message);
    res.status(500).json({ success: false, message: "Error fetching route", error: error.message });
  }
});

// ============================================
// 12. EXTERNAL APIs - WEATHER API
// ============================================

app.get("/weather", async (req, res) => {
  console.log("[DEBUG] /weather API hit", req.query);
  try {
    const { city } = req.query;
    if (!city) {
      return res.status(400).json({ success: false, message: "city is required" });
    }
    let usedFallback = false;
    let apiResponse = null;
    try {
      const apiKey = process.env.OPENWEATHER_API_KEY;
      if (!apiKey) throw new Error("OPENWEATHER_API_KEY not set");
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;
      const response = await axios.get(url);
      apiResponse = response.data;
      console.log("[DEBUG] /weather API response:", JSON.stringify(apiResponse));
      const temperature = apiResponse.main.temp;
      const condition = apiResponse.weather[0].main;
      return res.json({
        success: true,
        data: {
          city: apiResponse.name,
          temperature: `${temperature}°C`,
          condition,
        },
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      usedFallback = true;
      console.error("[ERROR] /weather API error:", err.message);
    }
    // Fallback mock data
    const conditions = ["Clear", "Cloudy", "Rainy", "Windy", "Sunny"];
    const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
    const temperature = Math.floor(Math.random() * 35) + 5; // 5-40°C
    res.json({
      success: true,
      data: {
        city,
        temperature: `${temperature}°C`,
        condition: randomCondition,
        fallback: usedFallback,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[ERROR] /weather API outer error:", error.message);
    res.status(500).json({ success: false, message: "Error fetching weather", error: error.message });
  }
});
// ============================================
// HEALTH CHECK API
// ============================================

app.get("/health", async (req, res) => {
  let weatherApi = "working";
  let routeApi = "working";
  // Test weather API
  try {
    const apiKey = process.env.OPENWEATHER_API_KEY;
    if (!apiKey) throw new Error("OPENWEATHER_API_KEY not set");
    await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=London&appid=${apiKey}&units=metric`);
  } catch {
    weatherApi = "fallback";
  }
  // Test route API
  try {
    const apiKey = process.env.OPENROUTE_API_KEY;
    if (!apiKey) throw new Error("OPENROUTE_API_KEY not set");
    await axios.get(`https://api.openrouteservice.org/v2/directions/driving-car?api_key=${apiKey}&start=77.5946,12.9716&end=77.2090,28.6139`);
  } catch {
    routeApi = "fallback";
  }
  res.json({
    status: "ok",
    server: "running",
    weatherApi,
    routeApi
  });
});

// ============================================
// SOCKET.IO REAL-TIME FEATURES
// ============================================

io.on("connection", (socket) => {
  console.log("User connected");
  // Listen for client-side statusUpdate events
  socket.on("statusUpdate", (data) => {
    console.log("[SOCKET] statusUpdate from client", data);
    io.emit("statusUpdate", data);
    console.log("[SOCKET] Broadcasted statusUpdate");
  });
  // Listen for client-side locationUpdate events
  socket.on("locationUpdate", (data) => {
    console.log("[SOCKET] locationUpdate from client", data);
    io.emit("locationUpdate", data);
    console.log("[SOCKET] Broadcasted locationUpdate");
  });
  // Custom event: user typing
  socket.on("userTyping", (data) => {
    console.log("[SOCKET] userTyping", data);
    socket.broadcast.emit("userTyping", { userId: data.userId, socketId: socket.id });
  });
  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
  socket.on("error", (error) => {
    console.error("[SOCKET] error", error);
  });
});

// ============================================
// ERROR HANDLING & SERVER START
// ============================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Endpoint not found",
    path: req.path,
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error("❌ Server error:", err);
  res.status(500).json({
    success: false,
    message: "Internal server error",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`
🚀 FlowSync Backend Running
📍 Server: http://localhost:${PORT}
🔌 WebSocket: ws://localhost:${PORT}
🌍 CORS: Enabled for all origins
⏰ Started at: ${new Date().toISOString()}
  `);
});

// Graceful shutdown
process.on("SIGTERM", () => {
  console.log("📛 SIGTERM received. Shutting down gracefully...");
  server.close(() => {
    console.log("✅ Server closed");
    process.exit(0);
  });
});